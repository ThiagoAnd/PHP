<div class="topo">
    <div class="row">
        <div class="col-md-8">
            <div class="logo">
                <a class="link" href="./home.php">
                    <h2>Faculdade Fatads</h2>
                </a>
            </div>
        </div>
        <div class="col-md-2">
            <div class="cadastrar">
                <button type="button" class="btn btn-success"> Cadastra-se </button>
            </div>
        </div>
        <div class="col-md-2">
            <div class="aluno">
                <a href="#"><i class="fas fa-user-graduate"><span> SOU ALUNO </span></i></a>
                <a href="#"><i class="fas fa-phone"><span> CONTATO </span></i></a>
            </div>
        </div>
    </div>
</div>
