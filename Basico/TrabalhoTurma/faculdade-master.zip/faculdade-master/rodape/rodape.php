<i class="fas fa-copyright"></i>
<span>2019 - T.A.D.S. 3º Período - Todos os Direitos reservados. </span>