<ul class="nav justify-content-center">
    <li class="nav-item">
        <a class="nav-link" title="Home" href="./home.php">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Taty" href="./formulario_taty.php">Protocolo</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Bruno" href="./formulario_bruno.php">Chamada</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Jorge" href="./formulario_jorge.php">Professor</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Thiago" href="./formulario_thiago.php">Aluno</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Luiz/Savio" href="./formulario_luiz_savio.php">Ponto</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Giovani" href="./formulario_giovani.php">Funcionário</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Vinicius" href="./formulario_vinicius.php">Estacionamento</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Gabriel B" href="./formulario_gabriel_b.php">Nota</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Gabriel R" href="./formulario_gabriel_r.php">Turma</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Matheus" href="./formulario_matheus.php">Fornecedor</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Diego" href="./formulario_diego.php">Disciplina</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Karam" href="./formulario_karam.php">Cantina</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" title="Jackson" href="./formulario_jackson.php">Sala</a>
    </li>
</ul>